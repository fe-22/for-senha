package com.fernandoalexthec.spfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpfirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpfirstApplication.class, args);
	}

}
