package com.fernandoalexthec.tom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TomApplicationTests {

	@Test
	void contextLoads() {
	}

}
